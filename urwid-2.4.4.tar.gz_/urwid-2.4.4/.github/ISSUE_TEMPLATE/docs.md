---
name: Documentation issue
about: Documentation related issue or request
title: "[docs]"
labels: docs
assignees: ''

---

##### Description:
[...]

##### Affected versions (if applicable)
- [ ] `master` branch (specify commit)
- [ ] Latest stable version from `pypi`
