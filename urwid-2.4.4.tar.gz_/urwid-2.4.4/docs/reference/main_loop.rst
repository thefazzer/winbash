MainLoop and Event Loops
========================

.. currentmodule:: urwid

MainLoop
--------

.. autoclass:: MainLoop

SelectEventLoop
---------------

.. autoclass:: SelectEventLoop

AsyncioEventLoop
----------------

.. autoclass:: AsyncioEventLoop

TrioEventLoop
----------------

.. autoclass:: TrioEventLoop

GLibEventLoop
-------------

.. autoclass:: GLibEventLoop

TwistedEventLoop
----------------

.. autoclass:: TwistedEventLoop

TornadoEventLoop
----------------

.. autoclass:: TornadoEventLoop

ZMQEventLoop
------------

.. autoclass:: ZMQEventLoop
