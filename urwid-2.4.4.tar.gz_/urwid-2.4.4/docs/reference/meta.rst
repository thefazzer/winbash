Metaclasses
===========

.. currentmodule:: urwid

.. autoclass:: WidgetMeta

.. autoclass:: MetaSuper

.. autoclass:: MetaSignals
