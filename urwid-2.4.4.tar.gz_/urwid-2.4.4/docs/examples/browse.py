#!/usr/bin/env python

from __future__ import annotations

import os

import real_browse

os.chdir('/usr/share/doc/python')
real_browse.main()
